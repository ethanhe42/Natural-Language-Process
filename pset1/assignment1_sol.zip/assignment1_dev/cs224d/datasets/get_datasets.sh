# Get Stanford Sentiment Treebank
wget http://nlp.stanford.edu/~socherr/stanfordSentimentTreebank.zip
unzip stanfordSentimentTreebank.zip
rm stanfordSentimentTreebank.zip
